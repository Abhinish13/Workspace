#!/bin/bash

MONGODB_IP=$(docker inspect --format {{.NetworkSetting.IPAddress}} some-mongo

export MONGO_URL="mongodb://
